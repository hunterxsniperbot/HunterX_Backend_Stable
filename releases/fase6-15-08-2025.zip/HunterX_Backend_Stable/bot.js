import "./src/boot/errors.js";
// boot básico (dotenv + IPv4 + HTTP keep-alive + pre-warm + typing)
import "dotenv/config";
import { setDefaultResultOrder } from "node:dns"; setDefaultResultOrder("ipv4first");
import "./src/boot/http.js";
import "./src/boot/prewarm.js";
import { hookTyping } from "./src/boot/typing.js";

// Telegram
import TelegramBot from "node-telegram-bot-api";

// Handlers
import registerAjustes     from "./src/commands/ajustes.js";
import registerSniperReset from "./src/commands/sniperReset.js";
import registerAutoSniper  from "./src/commands/autoSniper.js";
import registerMensaje     from "./src/commands/mensaje.js";
import registerRegistro    from "./src/commands/registro.js";
import registerWallet      from "./src/commands/wallet.js";
import registerHealth      from "./src/commands/health.js";
import registerStatus      from "./src/commands/status.js";
import registerInitSheets  from "./src/commands/initSheets.js";
import registerPick        from "./src/commands/pick.js";
import registerMode        from "./src/commands/mode.js";

// Servicios (inyectados a handlers)
import * as quickNodeClient from "./src/services/quicknode.js";
import * as phantomClient   from "./src/services/phantom.js";
import * as trading         from "./src/services/trading.js";

/* ────────────────────────────────────────────────────────────────────────── */
/* Guards anti doble inicio                                                  */
/* ────────────────────────────────────────────────────────────────────────── */
if (global.__HX_STARTED__) {
  console.log("⚠️ Bot ya estaba iniciado, evito doble bootstrap");
} else {
  global.__HX_STARTED__ = true;
}

let bot = global.__HX_BOT__;
if (!bot) {
  const TOKEN = process.env.TELEGRAM_BOT_TOKEN;
  if (!TOKEN) {
    console.error("❌ Falta TELEGRAM_BOT_TOKEN en .env");
    process.exit(1);
  }
  // Polling con menos latencia percibida
  bot = new TelegramBot(TOKEN, { polling: { interval: 100, params: { timeout: 10 } } });
  hookTyping(bot);
  global.__HX_BOT__ = bot;

  bot.on("polling_error", (e) => {
    const m = String(e?.message || e || "");
    if (m.match(/EFATAL|ETIMEDOUT|ECONNRESET|ECONNABORTED|ENOTFOUND/)) {
      console.log("🌐 [polling] aviso:", m);
    } else {
      console.error("❌ [polling_error]", m);
    }
  });

  console.log("🛰️ [TG] Modo: POLLING");
}

/* ────────────────────────────────────────────────────────────────────────── */
/* Menú de comandos (slash)                                                  */
/* ────────────────────────────────────────────────────────────────────────── */
async function setSlashMenu() {
  const commands = [
    { command: "health",     description: "Conexiones activas" },
    { command: "autosniper", description: "Activar sniper automático" },
    { command: "real",       description: "Modo trading REAL" },
    { command: "demo",       description: "Modo DEMO (simulación)" },
    { command: "stop",       description: "Detener sniper" },
    { command: "wallet",     description: "Ver posiciones abiertas" },
    { command: "registro",   description: "Ver posiciones cerradas" },
    { command: "discord",    description: "Tendencias en Discord" },
    { command: "ajustes",    description: "Configurar sniper" },
    { command: "mensaje",    description: "Ayuda / panel" }
  ];
  try {
    await bot.setMyCommands(commands);
    console.log("🟦 [Slash] comandos seteados");
  } catch (e) {
    console.error("❌ setMyCommands:", e?.message || e);
  }
}

/* ────────────────────────────────────────────────────────────────────────── */
/* Limpieza de reply-keyboards heredados                                     */
/* ────────────────────────────────────────────────────────────────────────── */
bot._kbCleanAt = bot._kbCleanAt || {};
bot.on("message", async (msg) => {
  try {
    if (msg.via_bot || msg.reply_to_message) return;
    const chatId = msg.chat.id;
    const last = bot._kbCleanAt[chatId] || 0;
    if (Date.now() - last < 60_000) return;
    await bot.sendMessage(chatId, " ", { reply_markup: { remove_keyboard: true } });
    bot._kbCleanAt[chatId] = Date.now();
  } catch {}
});

/* ────────────────────────────────────────────────────────────────────────── */
/* Registro de handlers (uno por bloque, logs claros)                        */
/* ────────────────────────────────────────────────────────────────────────── */
if (!global.__HX_HANDLERS_REGISTERED__) {
  console.log("🔧 Iniciando bot…");
  try { registerAjustes(bot, { quickNodeClient, phantomClient }); console.log("✅ Handler cargado: ajustes.js"); } catch(e){ console.error("❌ ajustes:", e?.message||e); }
  try { registerSniperReset(bot); console.log("✅ Handler cargado: sniperReset.js"); } catch(e){ console.error("❌ sniperReset:", e?.message||e); }
  try { registerAutoSniper(bot, { quickNodeClient, phantomClient, trading }); console.log("✅ Handler cargado: autoSniper.js"); } catch(e){ console.error("❌ autoSniper:", e?.message||e); }
  try { registerWallet(bot, { quickNodeClient, phantomClient, trading }); console.log("✅ Handler cargado: wallet.js"); } catch(e){ console.error("❌ wallet:", e?.message||e); }
  try { registerRegistro(bot, { trading }); console.log("✅ Handler cargado: registro.js"); } catch(e){ console.error("❌ registro:", e?.message||e); }
  try { registerMensaje(bot); console.log("✅ Handler cargado: mensaje.js"); } catch(e){ console.error("❌ mensaje:", e?.message||e); }
  try { registerHealth(bot, { quickNodeClient, phantomClient }); console.log("✅ Handler cargado: health.js"); } catch(e){ console.error("❌ health:", e?.message||e); }
  try { registerStatus(bot); console.log("✅ Handler cargado: status.js"); } catch(e){ console.error("❌ status:", e?.message||e); }
  try { registerInitSheets(bot); console.log("✅ Handler cargado: initSheets.js"); } catch(e){ console.error("❌ initSheets:", e?.message||e); }
  try { registerPick(bot); console.log("✅ Handler cargado: pick.js"); } catch(e){ console.error("❌ pick:", e?.message||e); }
  try { registerMode(bot); console.log("✅ Handler cargado: mode.js"); } catch(e){ console.error("❌ mode:", e?.message||e); }

  await setSlashMenu();
  global.__HX_HANDLERS_REGISTERED__ = true;
  console.log("🤖 HunterX Bot arrancado y escuchando comandos");
} else {
  console.log("⚠️ Handlers ya estaban registrados (evito duplicar)");
}

/* ────────────────────────────────────────────────────────────────────────── */
/* Atajo /discord si no hay handler dedicado                                 */
/* ────────────────────────────────────────────────────────────────────────── */
bot.onText(/^\/discord$/, (msg) => {
  bot.sendMessage(
    msg.chat.id,
    "👾 Discord tendencias: https://discord.gg/tu-invite",
    { disable_web_page_preview: true }
  ).catch(()=>{});
});
