// src/modules/start.js

/**
 * Módulo 1: Handler /start
 * Envía el mensaje de bienvenida e inicializa/verifica servicios en "frío".
 *
 * @param {TelegramBot} bot       Instancia de node-telegram-bot-api
 * @param {Object} services       Objetos de servicio inyectados
 *   - services.quickNode       Cliente QuickNode (RPC)
 *   - services.phantom         Cliente o helper de Phantom Wallet
 *   - services.supabase        Cliente Supabase
 *   - services.sheets          Cliente Google Sheets
 */
module.exports = function registerStartCommand(bot, services) {
  bot.onText(/\/start/, async (msg) => {
    const chatId = msg.chat.id;

    // 1) Verificamos cada servicio en "frío"
    try {
      await services.quickNode.ping();          // ping a tu RPC de Solana
    } catch (e) {
      console.error('QuickNode ping failed:', e);
    }

    try {
      await services.phantom.healthCheck();     // chequeo de conexión con Phantom
    } catch (e) {
      console.error('Phantom health check failed:', e);
    }

    try {
      await services.supabase.ping();           // ping a tu BD de trades
    } catch (e) {
      console.error('Supabase ping failed:', e);
    }

    try {
      await services.sheets.ping();             // ping a Google Sheets
    } catch (e) {
      console.error('Sheets ping failed:', e);
    }

    // 2) Enviamos mensaje de bienvenida
    const welcomeMessage = [
      '📲 *Iniciando HunterX...*',
      '🌐 Conectado a QuickNode',
      '📡 Escaneando blockchain de Solana...',
      '🧠 Activando IA predictiva',
      '🎯 Precisión quirúrgica ACTIVADA',
      '🚀 _¡Listo para cazar gemas!_'
    ].join('\n');

    await bot.sendMessage(chatId, welcomeMessage, {
      parse_mode: 'Markdown'
    });
  });
};
