# HunterX – Fase 1 (9 agosto 2025)

- Menú slash ordenado: /mensaje, /autosniper, /real, /demo, /stop, /wallet, /registro, /discord, /ajustes
- Sniper automático (/autosniper): slippage dinámico (IA opcional + heurística + Jupiter), anti-FOMO +100%/15s
- DEMO/REAL: marcado en compras/ventas y guardado en posiciones
- /wallet: PnL en vivo, refresco cada 5s, ventas 25/50/75/100, logs de ventas parciales y totales
- /registro: lee Google Sheets (por día), muestra Modo y resumen mensual parcial
- Sheets: columna "Mode", renombrado de pestaña mensual “Mes_Año (+NET USD)”
- Whitelist de comandos (evita chocar con handlers viejos)
