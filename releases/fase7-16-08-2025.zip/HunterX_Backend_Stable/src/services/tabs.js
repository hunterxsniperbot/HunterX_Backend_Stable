// src/services/tabs.js
export const TAB_DEMO = process.env.SHEETS_TAB_DEMO || process.env.GDEMO_TAB || 'DEMO';
export const TAB_REAL = process.env.SHEETS_TAB_REAL || process.env.GREAL_TAB || 'REAL';
