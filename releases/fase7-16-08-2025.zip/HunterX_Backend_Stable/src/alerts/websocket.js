/**
 * Módulo de Alertas: websocket/polling
 */
module.exports = {};
