// - Doble/Triple validación (DexScreener + Birdeye + Solscan*)
// - Cheques on-chain duros* (mint/freeze/upgrade/LP)  (*si tus servicios lo soportan)
// - Pre-sim Jupiter (quote) para estimar impacto real antes de comprar
// - Auto-tuning leve por franja prioritaria
// - Entrada 2 fases: probe -> scale-up
// - Giveback ladder configurable (paradas por caída desde pico)  [TU ESCALERA]
// - SL sólo para PROBE o si IA marca scam
// - Budget & Cooldown (límite $/hora y enfriamiento tras racha negativa)
// - Shadow trading: en REAL, registra también DEMO_SOMBRA (logging)
// - Monto por operación dinámico (5–2000) por modo (DEMO/REAL)
// - Degrada elegante cuando faltan APIs/keys (no rompe)

import * as markets       from '../services/markets.js';     // DexScreener/Birdeye/etc
import * as quicknode     from '../services/quicknode.js';    // on-chain opcional
import * as trading       from '../services/trading.js';      // logTrade/logEvent
import * as demoBank      from '../services/demoBank.js';     // simulador (si aplica)
import * as profileStore  from '../services/profile.js';      // perfiles (si aplica)
import * as supabase      from '../services/supabase.js';     // si querés hooks externos
import * as state        from '../services/state.js';     // persistencia simple ON/OFF

// ———————————————————————————————————————————————————————————
// Defaults desde .env (todo opcional, con fallback sensato)
// ———————————————————————————————————————————————————————————
const ENV = {
  PROFILE:                (process.env.PROFILE || 'maxseg').toLowerCase(),              // 'maxseg' | 'normal'
  BASE_DEMO:              clampNum(process.env.SNIPER_BASE_DEMO_USD, 100, 5, 2000),
  BASE_REAL:              clampNum(process.env.SNIPER_BASE_REAL_USD, 100, 5, 2000),
  DOWNSCALE_REAL:         readBool(process.env.AUTO_DOWNSCALE_REAL, true),

  PROBE_SL_PCT:           clampNum(process.env.PROBE_SL_PCT, 12, 5, 25),               // -5% a -25%
  MAX_IMPACT_PCT:         clampNum(process.env.JUPITER_MAX_IMPACT_PCT, 2.0, 0.5, 10),
  SCAN_MS:                clampNum(process.env.SCAN_INTERVAL_MS, 15000, 3000, 60000),

  // Giveback ladder (TU REGLA EXACTA por default)
  STOP_LADDER_JSON:       process.env.STOP_LADDER_JSON || JSON.stringify([
    { triggerUpPct: 100,  backToPct: 50,  sellPct: 100 },
    { triggerUpPct: 250,  backToPct: 125, sellPct: 100 },
    { triggerUpPct: 500,  backToPct: 200, sellPct: 100 },
    { triggerUpPct: 750,  backToPct: 300, sellPct: 100 },
    { triggerUpPct: 1000, backToPct: 400, sellPct: 100 },
    { triggerUpPct: 2000, backToPct: 800, sellPct: 100 },
  ]),

  BUDGET_DEMO_H:          clampNum(process.env.BUDGET_DEMO_USD_PER_H, 2000, 50, 100000),
  BUDGET_REAL_H:          clampNum(process.env.BUDGET_REAL_USD_PER_H, 500, 50, 100000),
  CD_RED_STREAK:          clampNum(process.env.COOLDOWN_RED_STREAK, 3, 1, 10),
  CD_MS:                  clampNum(process.env.COOLDOWN_MS, 15*60*1000, 60*1000, 24*60*60*1000),
};

// ———————————————————————————————————————————————————————————
// Perfiles de seguridad (máximos por default + auto-tuning por franja)
// ———————————————————————————————————————————————————————————
const BASE_RULES = {
  maxseg: {
    minLiquidityUsd:     40000,
    minHolders:          200,
    maxTop1Pct:          10,
    maxTop10Pct:         55,
    minVol5m:            25000,
    minTxPerMin:         25,
    minUniqueBuyersMin:  12,
    maxSpreadPct:        0.8,
    maxImpact100Pct:     2.0,
    maxRetracePct:       35,
    minBuyRatioPct:      65,
    requireLpLocked:     90,        // %
  },
  normal: {
    minLiquidityUsd:     25000,
    minHolders:          120,
    maxTop1Pct:          15,
    maxTop10Pct:         65,
    minVol5m:            15000,
    minTxPerMin:         15,
    minUniqueBuyersMin:  8,
    maxSpreadPct:        1.2,
    maxImpact100Pct:     3.0,
    maxRetracePct:       45,
    minBuyRatioPct:      60,
    requireLpLocked:     80,
  }
};

// ———————————————————————————————————————————————————————————
// Helpers base
// ———————————————————————————————————————————————————————————
function clampNum(v, def, min, max) {
  const n = Number(v);
  if (!Number.isFinite(n)) return def;
  return Math.max(min, Math.min(max, n));
}
function readBool(v, def=false) {
  if (v == null) return def;
  const s = String(v).toLowerCase().trim();
  return ['1','true','yes','on'].includes(s);
}
function n(v, d=null){ v = Number(v); return Number.isFinite(v)?v:d; }
function pct(a,b){ return (b>0) ? (a/b)*100 : null; }
const sleep = (ms)=> new Promise(r=>setTimeout(r,ms));
// Escapar HTML para parse_mode:"HTML"
function escHtml(s){
  return String(s)
    .replace(/&/g,'&amp;')
    .replace(/</g,'&lt;')
    .replace(/>/g,'&gt;');
}
// Escapa MarkdownV2 (evita 400 "can't parse entities")
// Escapa MarkdownV2 correctamente (un solo backslash antes de cada char reservado)
function mdv2(s){
  return String(s)
    .replace(/\\/g, '\\\\')                            // 1) duplicar backslashes existentes
    .replace(/([_*\\[\\]\\(\\)~`>#+\\-=|{}.!])/g, '\\$1'); // 2) escapar el resto con un solo "\"
}

// ———————————————————————————————————————————————————————————
// Franjas prioritarias (UTC-3): 9–12 / 13–16 / 17–20
// No detiene el scanner fuera de franja; sólo endurece un poco umbrales.
// ———————————————————————————————————————————————————————————
const PRIORITY_WINDOWS = [ [9,12], [13,16], [17,20] ];
function isPriorityNowUTC3() {
  const now = new Date();
  const utc = now.getUTCHours();
  const h = (utc + 21) % 24; // UTC-3 => -3h (equivale +21h mod 24)
  return PRIORITY_WINDOWS.some(([a,b]) => h >= a && h < b);
}
function tunedRules(profile){
  const base = { ...(BASE_RULES[profile] || BASE_RULES.maxseg) };
  if (isPriorityNowUTC3()) {
    // leve endurecimiento: +10% a mínimos, -10% a máximos
    base.minLiquidityUsd    = Math.round(base.minLiquidityUsd * 1.1);
    base.minHolders         = Math.round(base.minHolders * 1.1);
    base.minVol5m           = Math.round(base.minVol5m * 1.1);
    base.minTxPerMin        = Math.round(base.minTxPerMin * 1.1);
    base.minUniqueBuyersMin = Math.round(base.minUniqueBuyersMin * 1.1);
    base.maxSpreadPct       = +(base.maxSpreadPct * 0.9).toFixed(3);
    base.maxImpact100Pct    = +(base.maxImpact100Pct * 0.9).toFixed(3);
    base.maxRetracePct      = Math.round(base.maxRetracePct * 0.9);
  }
  return base;
}

// ———————————————————————————————————————————————————————————
// Kill-switch de Sniper por usuario (tracking + cancelables)
// ———————————————————————————————————————————————————————————
function _getSess(bot, uid) {
  bot._sniperSess = bot._sniperSess || {};
  bot._sniperSess[uid] = bot._sniperSess[uid] || {
    abort: new AbortController(),
    timeouts: new Set(),
    intervals: new Set(),
  };
  return bot._sniperSess[uid];
}
function _ensureAbort(bot, uid){
  const s = _getSess(bot, uid);
  if (!s.abort || s.abort?.signal?.aborted) s.abort = new AbortController();
  return s.abort;
}
function _trackTimeout(bot, uid, id) { _getSess(bot, uid).timeouts.add(id); return id; }
function _trackInterval(bot, uid, id) { _getSess(bot, uid).intervals.add(id); return id; }
function _clearTracked(bot, uid) {
  const s = _getSess(bot, uid);
  // abortar tareas cancelables
  try { s.abort?.abort?.(); } catch {}
  s.abort = new AbortController();
  // limpiar timers
  for (const t of s.timeouts) { try { clearTimeout(t); } catch {} }
  for (const i of s.intervals){ try { clearInterval(i); } catch {} }
  s.timeouts.clear(); s.intervals.clear();
}
async function csleep(bot, uid, ms) {
  // sleep cancelable por OFF
  const ctrl = _ensureAbort(bot, uid);
  return new Promise((resolve, reject) => {
    if (ctrl.signal.aborted) return resolve();
    const tid = setTimeout(resolve, ms);
    _trackTimeout(bot, uid, tid);
    const onAbort = () => { try { clearTimeout(tid); } catch {}; resolve(); };
    ctrl.signal.addEventListener('abort', onAbort, { once:true });
  });
}

// ———————————————————————————————————————————————————————————
// Validaciones Multi-feed (DexScreener + Birdeye + Solscan) y On-chain
// Todos son “best-effort”: si falta un feed, no rompe.
// ———————————————————————————————————————————————————————————
async function multiValidate(mintOrSym, rules) {
  const out = { ok:true, why:[], metrics:{} };

  // DexScreener
  const ds = await markets.getDexScreener?.(mintOrSym).catch(()=>null);
  if (ds?.priceUsd) out.metrics.price_ds = n(ds.priceUsd);
  if (ds?.liquidityUsd) out.metrics.liq_ds = n(ds.liquidityUsd);
  if (ds?.spreadPct) out.metrics.spread_ds = n(ds.spreadPct);
  if (ds?.vol5m) out.metrics.vol5m_ds = n(ds.vol5m);
  if (ds?.txPerMin) out.metrics.txpm_ds = n(ds.txPerMin);
  if (ds?.uniqueBuyersMin) out.metrics.ubuy_ds = n(ds.uniqueBuyersMin);
  if (ds?.holders) out.metrics.holders_ds = n(ds.holders);
  if (ds?.top1Pct) out.metrics.top1_ds = n(ds.top1Pct);
  if (ds?.top10Pct) out.metrics.top10_ds = n(ds.top10Pct);
  if (ds?.lpLockOrBurnPct) out.metrics.lp_ds = n(ds.lpLockOrBurnPct);

  // Birdeye
  const be = await markets.getBirdeye?.(mintOrSym).catch(()=>null);
  if (be?.priceUsd) out.metrics.price_be = n(be.priceUsd);
  if (be?.liquidityUsd) out.metrics.liq_be = n(be.liquidityUsd);
  if (be?.spreadPct) out.metrics.spread_be = n(be.spreadPct);
  if (be?.vol5m) out.metrics.vol5m_be = n(be.vol5m);
  if (be?.txPerMin) out.metrics.txpm_be = n(be.txPerMin);
  if (be?.uniqueBuyersMin) out.metrics.ubuy_be = n(be.uniqueBuyersMin);
  if (be?.holders) out.metrics.holders_be = n(be.holders);
  if (be?.top1Pct) out.metrics.top1_be = n(be.top1Pct);
  if (be?.top10Pct) out.metrics.top10_be = n(be.top10Pct);
  if (be?.lpLockOrBurnPct) out.metrics.lp_be = n(be.lpLockOrBurnPct);

  // Solscan (si tenés wrapper)
  const ss = await markets.getSolscan?.(mintOrSym).catch(()=>null);
  if (ss?.priceUsd) out.metrics.price_ss = n(ss.priceUsd);
  if (ss?.liquidityUsd) out.metrics.liq_ss = n(ss.liquidityUsd);
  if (ss?.holders) out.metrics.holders_ss = n(ss.holders);
  if (ss?.lpLockOrBurnPct) out.metrics.lp_ss = n(ss.lpLockOrBurnPct);

  // Chequeo consistencia básica (si ambos disponibles)
  if (out.metrics.liq_ds!=null && out.metrics.liq_be!=null) {
    const diff = Math.abs(out.metrics.liq_ds - out.metrics.liq_be) / Math.max(1, Math.min(out.metrics.liq_ds, out.metrics.liq_be));
    if (diff > 0.35) { out.ok=false; out.why.push('liquidez DS/BE difiere >35%'); }
  }

  // Tomar “mejor” estimación por campo (max/avg simple)
  const liqs = [out.metrics.liq_ds, out.metrics.liq_be, out.metrics.liq_ss].filter(x=>x!=null);
  const prices = [out.metrics.price_ds, out.metrics.price_be, out.metrics.price_ss].filter(x=>x!=null);
  const spreads = [out.metrics.spread_ds, out.metrics.spread_be].filter(x=>x!=null);
  const vol5m = [out.metrics.vol5m_ds, out.metrics.vol5m_be].filter(x=>x!=null);
  const txpm = [out.metrics.txpm_ds, out.metrics.txpm_be].filter(x=>x!=null);
  const ubuy = [out.metrics.ubuy_ds, out.metrics.ubuy_be].filter(x=>x!=null);
  const holders = [out.metrics.holders_ds, out.metrics.holders_be, out.metrics.holders_ss].filter(x=>x!=null);
  const top1 = [out.metrics.top1_ds, out.metrics.top1_be].filter(x=>x!=null);
  const top10= [out.metrics.top10_ds, out.metrics.top10_be].filter(x=>x!=null);
  const lp   = [out.metrics.lp_ds, out.metrics.lp_be, out.metrics.lp_ss].filter(x=>x!=null);

  const m = {
    priceUsd:         prices.length ? avg(prices) : null,
    liquidityUsd:     liqs.length ? Math.max(...liqs) : null,
    spreadPct:        spreads.length ? avg(spreads) : null,
    vol5mUsd:         vol5m.length ? Math.max(...vol5m) : null,
    txPerMin:         txpm.length ? Math.max(...txpm) : null,
    buyersPerMin:     ubuy.length ? Math.max(...ubuy) : null,
    holders:          holders.length ? Math.max(...holders) : null,
    top1Pct:          top1.length ? Math.max(...top1) : null,
    top10Pct:         top10.length ? Math.max(...top10) : null,
    lpLockOrBurnPct:  lp.length ? Math.max(...lp) : null,
  };

  // On-chain duro (si quicknode tiene helpers)
  if (quicknode.getMintAuthorities) {
    const a = await quicknode.getMintAuthorities(mintOrSym).catch(()=>null);
    if (a?.hasMintAuthority === true) { out.ok=false; out.why.push('mint authority activa'); }
    if (a?.hasFreezeAuthority === true) { out.ok=false; out.why.push('freeze authority activa'); }
    if (a?.isUpgradeable === true) { out.ok=false; out.why.push('contrato upgradeable'); }
  }
  if (quicknode.getLpState) {
    const lpst = await quicknode.getLpState(mintOrSym).catch(()=>null);
    if (lpst?.unlockSoon === true) { out.ok=false; out.why.push('LP unlock inminente'); }
  }

  // Reglas duras contra métricas
  if (m.liquidityUsd!=null && m.liquidityUsd < rules.minLiquidityUsd) { out.ok=false; out.why.push('liquidez baja'); }
  if (m.holders!=null      && m.holders      < rules.minHolders)      { out.ok=false; out.why.push('holders bajos'); }
  if (m.top1Pct!=null      && m.top1Pct      > rules.maxTop1Pct)       { out.ok=false; out.why.push('top1 concentrado'); }
  if (m.top10Pct!=null     && m.top10Pct     > rules.maxTop10Pct)      { out.ok=false; out.why.push('top10 concentrado'); }
  if (m.spreadPct!=null    && m.spreadPct    > rules.maxSpreadPct)     { out.ok=false; out.why.push('spread alto'); }
  if (m.vol5mUsd!=null     && m.vol5mUsd     < rules.minVol5m)         { out.ok=false; out.why.push('vol 5m bajo'); }
  if (m.txPerMin!=null     && m.txPerMin     < rules.minTxPerMin)      { out.ok=false; out.why.push('tx/min bajo'); }
  if (m.buyersPerMin!=null && m.buyersPerMin < rules.minUniqueBuyersMin){out.ok=false; out.why.push('buyers/min bajo'); }
  if (m.lpLockOrBurnPct!=null && m.lpLockOrBurnPct < rules.requireLpLocked) {
    out.ok=false; out.why.push('LP lock/burn insuficiente');
  }

  out.metrics = m;
  return out;
}
function avg(arr){ return arr.reduce((a,b)=>a+b,0)/arr.length; }

// ———————————————————————————————————————————————————————————
// Pre-sim Jupiter (quote). Si el impacto > tope, abortamos compra.
// markets.getJupiterQuote(mintIn, mintOut, amountUsd, slippagePct) => { priceImpactPct, outAmountUsd }
// Degradación elegante si no existe el servicio.
// ———————————————————————————————————————————————————————————
async function preSimJupiter({ mintIn, mintOut, amountUsd, slippagePct }) {
  if (!markets.getJupiterQuote) return null;
  try {
    const q = await markets.getJupiterQuote(mintIn, mintOut, amountUsd, slippagePct);
    if (!q) return null;
    return {
      priceImpactPct: n(q.priceImpactPct, null),
      outAmountUsd:   n(q.outAmountUsd, null)
    };
  } catch { return null; }
}

// ———————————————————————————————————————————————————————————
 // Entrada 2 fases (probe/full) + momentum simple opcional (intel)
// ———————————————————————————————————————————————————————————
function momentumGate(intel, rules){
  // intel: { hhhl:boolean, retracePct:number, buyRatioPct:number }
  const retr = n(intel?.retracePct, null);
  const buyR = n(intel?.buyRatioPct, null);
  const hhhl = !!intel?.hhhl;

  if (!hhhl) return {ok:false, why:'sin HH/HL'};
  if (retr!=null && retr > rules.maxRetracePct)   return {ok:false, why:'retroceso alto'};
  if (buyR!=null && buyR < rules.minBuyRatioPct)  return {ok:false, why:'buy ratio bajo'};
  return {ok:true};
}
function decideEntry({ profile, intel, ageSec }) {
  const rules = tunedRules(profile);
  const slipBase = Math.min(0.8, rules.maxSpreadPct); // slip base ≈ spread tope

  if (ageSec!=null && ageSec < 60) {
    const m = momentumGate(intel, rules);
    if (!m.ok) return { action:'block', reason:`early ${m.why}` };
    return { action:'probe', sizePct: 0.2, slippagePct: Math.min(1.2, slipBase + 0.4) };
  }
  const m = momentumGate(intel, rules);
  if (m.ok) return { action:'full',  sizePct: 1.0, slippagePct: slipBase };
  return { action:'probe', sizePct: 0.3, slippagePct: slipBase };
}

// ———————————————————————————————————————————————————————————
// Stores por usuario y modo
// p: {mint, symbol, qty, avg, highest, lastBuyTs}
// ———————————————————————————————————————————————————————————
function getStore(bot, uid, mode) {
  const key = mode === 'REAL' ? '_store_real' : '_store_demo';
  bot[key] = bot[key] || {};
  bot[key][uid] = bot[key][uid] || {};
  return bot[key][uid];
}
function addBuyPosition(store, mint, symbol, qty, price) {
  const p = store[mint] || { mint, symbol, qty:0, avg:0, highest:0 };
  const totalCost = p.avg * p.qty + price * qty;
  const newQty    = p.qty + qty;
  p.avg     = newQty > 0 ? totalCost / newQty : 0;
  p.qty     = newQty;
  p.highest = Math.max(p.highest || 0, price);
  p.lastBuyTs = Date.now();
  store[mint] = p;
}
function dropQty(store, mint, qty) {
  const p = store[mint];
  if (!p) return;
  p.qty = Math.max(0, p.qty - qty);
  if (p.qty === 0) delete store[mint];
}

// ———————————————————————————————————————————————————————————
// Budget / cooldown por usuario
// ———————————————————————————————————————————————————————————
function getRisk(bot, uid) {
  bot._risk = bot._risk || {};
  bot._risk[uid] = bot._risk[uid] || { lastHour: null, spentDemo:0, spentReal:0, redStreak:0, cooldownUntil:0 };
  return bot._risk[uid];
}
function withinHourBudget(risk, mode, baseUsd) {
  const now = new Date();
  const hourKey = now.getUTCFullYear()+'-'+(now.getUTCMonth()+1)+'-'+now.getUTCDate()+'-'+now.getUTCHours();
  if (risk.lastHour !== hourKey) {
    risk.lastHour = hourKey;
    risk.spentDemo = 0;
    risk.spentReal = 0;
  }
  if (Date.now() < risk.cooldownUntil) return { ok:false, why:'cooldown activo' };

  if (mode === 'DEMO') {
    if (risk.spentDemo + baseUsd > ENV.BUDGET_DEMO_H) return { ok:false, why:'budget DEMO/h superado' };
    return { ok:true };
  } else {
    if (risk.spentReal + baseUsd > ENV.BUDGET_REAL_H) return { ok:false, why:'budget REAL/h superado' };
    return { ok:true };
  }
}
function registerSpend(risk, mode, usd) {
  if (mode === 'DEMO') risk.spentDemo += usd; else risk.spentReal += usd;
}
function registerPnL(bot, uid, pnlUsd) {
  const r = getRisk(bot, uid);
  if (pnlUsd < 0) r.redStreak += 1; else r.redStreak = 0;
  if (r.redStreak >= ENV.CD_RED_STREAK) {
    r.cooldownUntil = Date.now() + ENV.CD_MS;
    r.redStreak = 0;
  }
}

// ———————————————————————————————————————————————————————————
// Exec buys / sells (REAL ↔ Phantom / DEMO ↔ demoBank) + log
// ———————————————————————————————————————————————————————————
async function execBuy({ bot, uid, mode, mint, symbol, amountUsd, slippagePct, phantomClient }) {
  // Pre-sim Jupiter si existe
  const q = await preSimJupiter({
    mintIn: process.env.USDC_MINT || 'USDC',
    mintOut: mint,
    amountUsd,
    slippagePct
  });
  if (q && n(q.priceImpactPct, 0) > ENV.MAX_IMPACT_PCT) {
    await trading.logEvent({ mode, type:'blocked', token:symbol, mint, fuente:'preSim', extra:{ impact:q.priceImpactPct } });
    return { ok:false, why:'impacto jupiter alto' };
  }

  if (mode === 'REAL') {
    if (!phantomClient?.buyToken) return { ok:false, why:'phantomClient.buyToken faltante' };
    if (ENV.DOWNSCALE_REAL && phantomClient.getUsdcBalance) {
      const usdc = await phantomClient.getUsdcBalance().catch(()=>null);
      if (usdc != null && usdc < amountUsd) {
        if (usdc < 5) return { ok:false, why:'USDC insuficiente' };
        amountUsd = usdc; // auto-downscale
      }
    }
    const tx = await phantomClient.buyToken({ mint, amountUsd, slippagePct }).catch(e=>({ ok:false, err:String(e?.message||e) }));
    if (!tx?.ok) return { ok:false, why:tx?.err||'compra REAL falló' };
    await trading.logTrade({
      mode, type:'buy', token:symbol, mint,
      inversion_usd: amountUsd, entrada_usd: tx.priceUsd || null,
      fuente:'AutoSniper', extra:{ txid: tx.txid, slip: slippagePct, presim:q?.priceImpactPct }
    });
    // Shadow logging DEMO
    await trading.logTrade({ mode:'DEMO', type:'shadow', token:symbol, mint, inversion_usd: amountUsd, entrada_usd: tx.priceUsd||null, fuente:'AutoSniper' });
    return { ok:true, price: tx.priceUsd || null, txid: tx.txid };
  } else {
    // DEMO
    const px = await markets.getPrice?.(mint).catch(()=>null);
    const price = n(px, 0.000001);
    const qty = amountUsd / Math.max(0.0000001, price);
    addBuyPosition(getStore(bot, uid, 'DEMO'), mint, symbol, qty, price);
    await trading.logTrade({ mode, type:'buy', token:symbol, mint, inversion_usd: amountUsd, entrada_usd: price, fuente:'AutoSniper' });
    return { ok:true, price, txid:'DEMO' };
  }
}

async function execSell({ bot, uid, mode, mint, symbol, amountToken, slippagePct, phantomClient }) {
  if (mode === 'REAL') {
    if (!phantomClient?.sellToken) return { ok:false, why:'phantomClient.sellToken faltante' };
    const tx = await phantomClient.sellToken({ mint, amountToken, slippagePct }).catch(e=>({ ok:false, err:String(e?.message||e) }));
    if (!tx?.ok) return { ok:false, why:tx?.err||'venta REAL falló' };
    return { ok:true, price: tx.priceUsd || null, txid: tx.txid };
  } else {
    // DEMO: sacamos qty; el precio de logging se resuelve afuera con cur
    dropQty(getStore(bot, uid, 'DEMO'), mint, amountToken);
    return { ok:true, price:null, txid:'DEMO' };
  }
}

// ———————————————————————————————————————————————————————————
// Gestión de salidas: SL de PROBE + IA scam + Giveback ladder (TU REGLA)
// ———————————————————————————————————————————————————————————
function parseLadder() {
  try { return JSON.parse(ENV.STOP_LADDER_JSON); }
  catch { return []; }
}
async function manageExits({ bot, uid, mode, store, p, cur, phantomClient }) {
  // 0) mantener "highest"
  p.highest = Math.max(p.highest || 0, cur);

  const pnlPct = p.avg>0 ? ((cur - p.avg) / p.avg) * 100 : 0;
  const peakPct= p.avg>0 && p.highest>0 ? ((p.highest - p.avg) / p.avg) * 100 : 0;

  // 1) SL sólo para PROBE (si compraste hace poco y está bajo agua) — opcional
  if (p.lastBuyTs && (Date.now() - p.lastBuyTs) < 60_000) {
    if (pnlPct <= -ENV.PROBE_SL_PCT) {
      const sellQty = p.qty;
      if (sellQty > 0) {
        const sold = await execSell({ bot, uid, mode, mint:p.mint, symbol:p.symbol, amountToken:sellQty, slippagePct:0.8, phantomClient });
        if (sold.ok) {
          dropQty(store, p.mint, sellQty);
          registerPnL(bot, uid, (cur - p.avg) * sellQty);
          await trading.logTrade({ mode, type:'sell', token:p.symbol, mint:p.mint, salida_usd: cur, inversion_usd: p.avg*sellQty, pnl_usd:(cur - p.avg)*sellQty, fuente:'AutoSniper', extra:{ kind:'probe_sl' } });
          return; // ya cerramos
        }
      }
    }
  }

  // 2) SL hard por IA scam (si tu pipeline marca p.aiScam=true). Si no existe, nunca dispara.
  if (p.aiScam === true && pnlPct < 0) {
    const sellQty = p.qty;
    if (sellQty > 0) {
      const sold = await execSell({ bot, uid, mode, mint:p.mint, symbol:p.symbol, amountToken:sellQty, slippagePct:0.8, phantomClient });
      if (sold.ok) {
        dropQty(store, p.mint, sellQty);
        registerPnL(bot, uid, (cur - p.avg) * sellQty);
        await trading.logTrade({ mode, type:'sell', token:p.symbol, mint:p.mint, salida_usd: cur, inversion_usd: p.avg*sellQty, pnl_usd:(cur - p.avg)*sellQty, fuente:'AutoSniper', extra:{ kind:'ai_scam' } });
        return;
      }
    }
  }

  // 3) Giveback ladder — EXACTAMENTE tu escalera por default (100→50, 250→125, etc.)
  const ladder = parseLadder();
  p._gbApplied = p._gbApplied || {};
  for (const r of ladder) {
    const key = `${r.triggerUpPct}_${r.backToPct}_${r.sellPct}`;
    if (p._gbApplied[key]) continue;
    if (peakPct >= r.triggerUpPct && pnlPct <= r.backToPct) {
      const sellQty = p.qty * (r.sellPct / 100);
      if (sellQty > 0) {
        const sold = await execSell({ bot, uid, mode, mint:p.mint, symbol:p.symbol, amountToken:sellQty, slippagePct:0.8, phantomClient });
        if (sold.ok) {
          dropQty(store, p.mint, sellQty);
          registerPnL(bot, uid, (cur - p.avg) * sellQty);
          p._gbApplied[key] = true;
          await trading.logTrade({ mode, type:'sell', token:p.symbol, mint:p.mint, salida_usd: cur, inversion_usd: p.avg*sellQty, pnl_usd:(cur - p.avg)*sellQty, fuente:'AutoSniper', extra:{ kind:'ladder', rule:r } });
        }
      }
    }
  }
}

// ———————————————————————————————————————————————————————————
// LOOP de escaneo y ejecución por usuario
// ———————————————————————————————————————————————————————————
async function loopForUser(bot, uid, { phantomClient }) {
  // GUARDAS: si se apagó o fue abortado, no corremos nada
  if (!bot._sniperOn?.[uid]) return;
  const _sess = (_getSess(bot, uid)) || null;
  if (_sess?.abort?.signal?.aborted) return;

  const profile = (await profileStore.getProfile?.(uid))?.sniperProfile || ENV.PROFILE; // 'maxseg'|'normal'
  const rules = tunedRules(profile);

  // 1) tomar modo actual
  const mode = bot.realMode?.[uid] ? 'REAL' : 'DEMO';
  const baseUsd = mode === 'REAL' ? ENV.BASE_REAL : ENV.BASE_DEMO;

  // 2) budgets / cooldown
  const risk = getRisk(bot, uid);
  const bud = withinHourBudget(risk, mode, baseUsd);
  if (!bud.ok) {
    await trading.logEvent({ mode, type:'cooldown_or_budget', fuente:'AutoSniper', extra:{ why:bud.why } });
    return;
  }

  // 3) obtener candidatos
  const cands = await (markets.scanNewTokens?.().catch(()=>[])) || [];
  // Si no hay feed, nada que hacer
  if (!Array.isArray(cands) || cands.length === 0) return;

  for (const cand of cands) {
    try {
      const mint   = cand.mint || cand.mintAddress || cand.address || null;
      const symbol = cand.symbol || (mint ? mint.slice(0,6)+'…' : 'TOKEN');
      if (!mint) continue;

      // 3.1 multi-validate + on-chain
      const mv = await multiValidate(mint, rules);
      if (!mv.ok) {
        await trading.logEvent({ mode, type:'blocked', token:symbol, mint, fuente:'multiValidate', extra:{ why: mv.why } });
        continue;
      }

      // 3.2 momentum & age
      const intel = {
        hhhl: !!cand.intel?.hhhl,
        retracePct: n(cand.intel?.retracePct, null),
        buyRatioPct: n(cand.intel?.buyRatioPct, null)
      };
      const ageSec = n(cand.metrics?.age_sec, null);

      // 3.3 decidir entrada (probe/full)
      const d = decideEntry({ profile, intel, ageSec });
      if (d.action === 'block') {
        await trading.logEvent({ mode, type:'blocked', token:symbol, mint, fuente:'entry', extra:{ why:d.reason } });
        continue;
      }

      // 3.4 ejecutar compra inicial
      const amountUsd = baseUsd * d.sizePct;
      const b = await execBuy({ bot, uid, mode, mint, symbol, amountUsd, slippagePct: d.slippagePct, phantomClient });
      if (!b.ok) {
        await trading.logEvent({ mode, type:'buy_fail', token:symbol, mint, fuente:'execBuy', extra:{ why: b.why } });
        continue;
      }

      // 3.5 si probe, evaluar scale-up en ~22s (cancelable por OFF)
      if (d.action === 'probe') {
        await csleep(bot, uid, 22_000); // cancelable
        // re-validar que siga ON (pudo apagarse durante la espera)
        if (!bot._sniperOn?.[uid]) continue;

        // revalidar momentum (reusar intel si no hay pipeline reactivo)
        const intel2 = {
          hhhl: !!cand.intel?.hhhl,
          retracePct: n(cand.intel?.retracePct, null),
          buyRatioPct: n(cand.intel?.buyRatioPct, null)
        };
        const m2 = momentumGate(intel2, rules);
        if (m2.ok) {
          const remain = baseUsd * (1.0 - d.sizePct);
          if (remain >= 5) {
            const b2 = await execBuy({ bot, uid, mode, mint, symbol, amountUsd: remain, slippagePct: Math.max(0.8, d.slippagePct), phantomClient });
            if (!b2.ok) {
              await trading.logEvent({ mode, type:'buy_fail', token:symbol, mint, fuente:'scaleUp', extra:{ why:b2.why } });
            }
          }
        }
      }

      // 3.6 registrar spend del primer tramo
      registerSpend(risk, mode, baseUsd);

    } catch (e) {
      await trading.logEvent({ mode: bot.realMode?.[uid] ? 'REAL':'DEMO', type:'error', fuente:'loopForUser', extra:{ err:String(e?.message||e) } });
    }
  }

  // 4) Gestión de salidas para TODAS las posiciones del usuario
  for (const MODE of ['DEMO','REAL']) {
    const store = getStore(bot, uid, MODE);
    for (const mint of Object.keys(store)) {
      const p = store[mint];
      const curPx = await markets.getPrice?.(mint).catch(()=>null);
      const cur = n(curPx, null);
      if (!Number.isFinite(cur)) continue;
      await manageExits({ bot, uid, mode: MODE, store, p, cur, phantomClient: MODE==='REAL' ? bot._phantomClient : null });
    }
  }
}

// ———————————————————————————————————————————————————————————
// Registro del comando /autosniper (on|off|stop|status)
// ———————————————————————————————————————————————————————————
export default function registerAutoSniper(bot, { phantomClient } = {}) {
  bot._sniperLoops = bot._sniperLoops || {};
  bot._phantomClient = phantomClient || bot._phantomClient || {};

  // Estado global por usuario
  bot._sniperOn = bot._sniperOn || {};
// Cargar ON/OFF persistido (no bloqueante)
  state.getSniperOnMap?.()
    .then((map)=>{ if (map && typeof map==='object') bot._sniperOn = { ...map, ...bot._sniperOn }; })
    .catch(()=>{});
  setTimeout(() => {
    try {
      const map = bot._sniperOn || {};
      for (const [uid, on] of Object.entries(map)) {
        if (!on) continue;
        if (bot._sniperLoops?.[uid]) continue; // ya estaba corriendo

        // Iniciar loop periódico (trackeado) con anti-reentrancia
        bot._sniperLoops = bot._sniperLoops || {};
        bot._running     = bot._running || {};
        bot._sniperLoops[uid] = _trackInterval(
          bot, uid,
          setInterval(() => {
            if (bot._running && bot._running[uid]) return; // anti-reentrancia
            bot._running[uid] = true;
            Promise.resolve(
              loopForUser(bot, uid, { phantomClient: bot._phantomClient })
            ).finally(() => { bot._running[uid] = false; });
          }, ENV.SCAN_MS)
        );

        // Corrida inmediata
        loopForUser(bot, uid, { phantomClient: bot._phantomClient }).catch(()=>{});
      }
    } catch {}
  }, 1500);

  // Limpia posibles listeners viejos (con y sin @mención)
  bot.removeTextListener?.(/^\s*\/autosniper(?:\s+(?:on|off|stop|status))?\s*$/i);
  bot.removeTextListener?.(/^\s*\/autosniper(?:@[\w_]+)?(?:\s+(?:on|off|stop|status))?\s*$/i);
  bot.removeTextListener?.(/^\/autosniper/i);

  bot.onText(/^\s*\/autosniper(?:@[\w_]+)?(?:\s+(on|off|stop|status))?\s*$/i, async (msg, m) => {
    const chatId = msg.chat.id;
    const uid    = String(msg.from.id);
    const arg    = ((m && m[1]) ? String(m[1]) : '').toLowerCase().trim();
    console.log(`[AUTOSNIPER] cmd arg="${arg||'(vacío)'}" uid=${uid}`);

    // OFF/STOP primero (determinístico)
    if (arg === 'off' || arg === 'stop') {
      if (bot._sniperLoops?.[uid]) {
        clearInterval(bot._sniperLoops[uid]);
        delete bot._sniperLoops[uid];
      }
      bot._sniperOn[uid] = false;
      if (bot._running && bot._running[uid]) delete bot._running[uid];
      state.setSniperOn?.(uid, false).catch(()=>{});
      _clearTracked(bot, uid); // mata sleeps/async/intervals
      return bot.sendMessage(chatId, '<b>🛑 Sniper OFF</b>', { parse_mode:'HTML' });
    }

    // STATUS — salida en HTML (sin MarkdownV2)
    // STATUS — salida en HTML (sin MarkdownV2)
    if (arg === 'status') {
      const on   = !!bot._sniperOn[uid];
      const mode = bot.realMode?.[uid] ? 'REAL' : 'DEMO';
      const prof = (await profileStore.getProfile?.(uid))?.sniperProfile || ENV.PROFILE;
      const pri  = isPriorityNowUTC3() ? 'Sí' : 'No';

      const lines = [
        '<b>📟 Sniper:</b> ' + (on ? '<b>ON</b>' : '<b>OFF</b>'),
        '• Modo: <b>' + escHtml(mode) + '</b>',
        '• Perfil: <b>' + escHtml(prof) + '</b>',
        '• Prioridad horaria ahora: <b>' + escHtml(pri) + '</b> (9–12 / 13–16 / 17–20 UTC−3)',
        '• Base DEMO/REAL: $' + ENV.BASE_DEMO + ' / $' + ENV.BASE_REAL,
        '• Ladder: <code>' + escHtml(ENV.STOP_LADDER_JSON) + '</code>'
      ];

      const text = lines.join('\n');
      return bot.sendMessage(chatId, text, { parse_mode:'HTML', disable_web_page_preview:true });
    }
    if (arg === 'on' || arg === '') {
      if (bot._sniperOn[uid]) {
        return bot.sendMessage(chatId, '<b>🤖 Sniper ya estaba ON</b> (modo: <b>' + (bot.realMode?.[uid]?'REAL':'DEMO') + '</b>)', { parse_mode:'HTML' });
      }
      bot._sniperOn[uid] = true;
      state.setSniperOn?.(uid, true).catch(()=>{});

      // sesión limpia (AbortController + tracking)
      _clearTracked(bot, uid);
      _ensureAbort(bot, uid);

      const mode = bot.realMode?.[uid] ? 'REAL' : 'DEMO';
      return bot.sendMessage(chatId, '<b>🤖 Sniper ON</b> — Modo: <b>' + mode + '</b> (modo: <b>' + (bot.realMode?.[uid]?'REAL':'DEMO') + '</b>). Escaneo continuo con prioridad por franjas.', { parse_mode:'HTML' });

      // Iniciar loop periódico (trackeado) + corrida inmediata
      if (bot._sniperLoops?.[uid]) clearInterval(bot._sniperLoops[uid]);
      bot._sniperLoops[uid] = _trackInterval(
        bot, uid,
        setInterval(() => {
          if (bot._running && bot._running[uid]) return; // anti-reentrancia
          bot._running = bot._running || {};
          bot._running[uid] = true;
          Promise.resolve(
            loopForUser(bot, uid, { phantomClient: bot._phantomClient })
          ).finally(() => { bot._running[uid] = false; });
        }, ENV.SCAN_MS)
      );
      // Corrida inmediata
      loopForUser(bot, uid, { phantomClient: bot._phantomClient }).catch(()=>{});
      return;
    }

    // Help
    bot.sendMessage(chatId, 'Uso: <code>/autosniper on</code> | <code>off</code> | <code>status</code>', { parse_mode:'HTML' });
  });

  // Compatibilidad: /stop para apagar rápido
  bot.removeTextListener?.(/^\/stop$/i);
  bot.onText(/^\/stop$/i, async (msg) => {
    const uid = String(msg.from.id);
    if (bot._sniperLoops[uid]) {
      clearInterval(bot._sniperLoops[uid]);
      delete bot._sniperLoops[uid];
    }
    bot._sniperOn[uid] = false;
      if (bot._running && bot._running[uid]) delete bot._running[uid];
      state.setSniperOn?.(uid, false).catch(()=>{});
    _clearTracked(bot, uid);
    bot.sendMessage(msg.chat.id, '<b>🛑 Sniper OFF</b>', { parse_mode:'HTML' });
  });
}
