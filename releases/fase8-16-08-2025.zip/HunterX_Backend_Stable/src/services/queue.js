export function queueTask(_task){ /* no-op */ }
export async function consumeTasks(){ /* no-op */ }
