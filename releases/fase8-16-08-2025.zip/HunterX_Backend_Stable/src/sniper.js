export async function runSniperTask(_task){ /* no-op */ }
